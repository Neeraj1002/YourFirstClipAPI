-- AlterTable
ALTER TABLE `portfolio` ADD COLUMN `isLive` BOOLEAN NOT NULL DEFAULT false;
