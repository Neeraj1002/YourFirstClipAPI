-- DropForeignKey
ALTER TABLE `portfolio` DROP FOREIGN KEY `portfolio_createdBy_fkey`;

-- DropForeignKey
ALTER TABLE `portfolio` DROP FOREIGN KEY `portfolio_updatedBy_fkey`;
